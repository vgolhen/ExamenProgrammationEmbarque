package com.golhenvalentine.cv_valentine_golhen

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
