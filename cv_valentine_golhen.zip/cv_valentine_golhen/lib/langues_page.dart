import 'package:cv_valentine_golhen/input_page.dart';
import 'package:flutter/material.dart';



class LanguesPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          GestureDetector(
            onTap: (){
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context)=>InputPage(),
                ),
              );
            },
            child: CarteReutilisable(
              couleur: Colors.orange.shade50,
              cardChild:Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    CircleAvatar(
                      radius: 20.0,
                      backgroundImage: AssetImage('images/image_de_fond.jpg'),
                    ),
                    SizedBox(
                      width: 10.0,
                    ),
                    Text(
                      'Valentine GOLHEN',
                      style: TextStyle(
                        fontSize: 25.0,
                        color: Colors.black,
                      ),
                    ),
                  ]
              ),
            ),
          ),
          Text(
            'Langues',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontFamily: 'Pacifico',
              fontSize: 40.0,
              color: Colors.white,
              fontWeight: FontWeight.bold,
            ),
          ),
          Expanded(
            child: Column(
              children: <Widget>[
                Expanded(
                  child: CarteReutilisable(
                    couleur: Colors.orange.shade50,
                    cardChild:Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          CircleAvatar(
                            radius: 15.0,
                            backgroundImage: AssetImage('images/english-flag.png'),
                          ),
                          SizedBox(
                            width: 10.0,
                          ),
                          Text(
                            'Anglais',
                            style: TextStyle(
                              fontSize: 25.0,
                              color: Colors.black,
                            ),
                          ),
                        ]
                    ),
                  ),
                ),
                Expanded(
                  child: CarteReutilisable(
                    couleur: Colors.orange.shade50,
                    cardChild:Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          CircleAvatar(
                            radius: 15.0,
                            backgroundImage: AssetImage('images/germany-flag.png'),
                          ),
                          SizedBox(
                            width: 10.0,
                          ),
                          Text(
                            'Allemand',
                            style: TextStyle(
                              fontSize: 25.0,
                              color: Colors.black,
                            ),
                          ),
                        ]
                    ),
                  ),
                ),
              ],
            ),
          ),

        ],
      ),
    );
  }
}

class CarteReutilisable extends StatelessWidget {
  final Color couleur;
  final Widget cardChild;
  CarteReutilisable({@required this.couleur, @required this.cardChild});

  @override
  Widget build(BuildContext context) {
    return Container(
      child: cardChild,
      margin: EdgeInsets.all(10.0),
      width: 200.0,
      height: 100.0,
      decoration: BoxDecoration(
        color: couleur,
        borderRadius: BorderRadius.circular(10.0),
      ),
    );
  }
}
